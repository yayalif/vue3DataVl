export const BASE_PATH_MAP = Symbol('path_map');
export const ROUTER_MAP = Symbol('route_map');