import log4js from 'log4js'

const log = log4js.getLogger('default');
export const errlog = log4js.getLogger('err');
export default log
