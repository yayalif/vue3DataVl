/*
 * @Description:
 * @Author: ZY
 * @Date: 2020-12-17 16:06:56
 * @LastEditors: ZY
 * @LastEditTime: 2020-12-17 16:35:33
 */

class Keys {
  static sidebarStatusKey = 'vue3-typescript-admin-sidebarStatusKey'
  static languageKey = 'vue3-typescript-admin-languageKey'
  static sizeKey = 'vue3-typescript-admin-sizeKey'
  static tokenKey = 'vue3-typescript-admin-access-token'
  static aseKey = 'vue3-typescript-admin-ase-key'
}

export default Keys
