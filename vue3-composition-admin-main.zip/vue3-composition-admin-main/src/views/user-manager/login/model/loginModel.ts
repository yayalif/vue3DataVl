/*
 * @Description:
 * @Author: ZY
 * @Date: 2020-12-29 09:12:24
 * @LastEditors: ZY
 * @LastEditTime: 2020-12-29 09:13:23
 */
// {
//     "code": 0,
//     "msg": "success",
//     "data": {
//         "accessToken": "admin-token"
//     }
// }

export interface LoginModel {
  accessToken: string
}
