<!--
 * @Description:
 * @Autor: WJM
 * @Date: 2021-01-18 14:53:33
 * @LastEditors: ZY
 * @LastEditTime: 2021-01-25 12:44:14
-->
<template>
  <div style="padding:30px;">
    <el-alert
      :closable="false"
      title="menu 2"
    />
  </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue'

export default defineComponent({

})
</script>
