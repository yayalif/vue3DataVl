<!--
 * @Description: 更新日志
 * @Author: ZY
 * @Date: 2021-01-18 17:13:09
 * @LastEditors: ZY
 * @LastEditTime: 2021-01-18 17:16:53
-->
<template>
  <el-card
    class="card"
    shadow="never"
  >
    <el-timeline>
      <el-timeline-item
        timestamp="2018/4/12"
        placement="top"
      >
        <el-card>
          <h4>更新 Github 模板</h4>
          <p>王小虎 提交于 2018/4/12 20:46</p>
          <p>王小虎 提交于 2018/4/12 20:46</p>
        </el-card>
      </el-timeline-item>
      <el-timeline-item
        timestamp="2018/4/3"
        placement="top"
      >
        <el-card>
          <h4>更新 Github 模板</h4>
          <p>王小虎 提交于 2018/4/3 20:46</p>
        </el-card>
      </el-timeline-item>
      <el-timeline-item
        timestamp="2018/4/2"
        placement="top"
      >
        <el-card>
          <h4>更新 Github 模板</h4>
          <p>王小虎 提交于 2018/4/2 20:46</p>
        </el-card>
      </el-timeline-item>
    </el-timeline>
  </el-card>
</template>

<script lang="ts">
import { defineComponent } from 'vue'

export default defineComponent({
  setup() {
    return {}
  }
})
</script>

<style scoped>

</style>
