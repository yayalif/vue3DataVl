/*
 * @Description: 项目类型声明
 * @Author: ZY
 * @Date: 2020-12-19 10:33:47
 * @LastEditors: ZY
 * @LastEditTime: 2021-01-19 16:05:14
 */

declare module '*.svg'
declare module '*.png'
declare module '*.jpg'
declare module '*.jpeg'
declare module '*.gif'
declare module '*.bmp'
declare module '*.tiff'
declare module '*.yaml'
declare module '*.json'
declare module 'vue-count-to'
