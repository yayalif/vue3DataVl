/*
 * @Description:
 * @Author: ZY
 * @Date: 2020-12-21 14:38:13
 * @LastEditors: ZY
 * @LastEditTime: 2020-12-21 15:00:34
 */
export interface ScssVariables {
  menuBg: string
  menuText: string
  menuActiveText: string
}

export const variables: IScssVariables

export default variables
