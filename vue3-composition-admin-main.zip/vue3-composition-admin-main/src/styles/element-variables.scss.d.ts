export interface ScssVariables {
  theme: string
}

export const variables: ScssVariables

export default variables
