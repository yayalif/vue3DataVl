/*
 * @Description:
 * @Author: ZY
 * @Date: 2021-01-21 16:53:48
 * @LastEditors: ZY
 * @LastEditTime: 2021-01-21 16:54:50
 */
export interface ArticleList<T> {
    total: number
    items: T[]
}
